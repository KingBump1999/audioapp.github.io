//
//  RhythmKraftApp.swift
//  RhythmKraft
//
//  Created by Irfan Navaz on 27/01/2024.
//

import SwiftUI

@main
struct RhythmKraftApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
