import SwiftUI
import AudioKit
class DrumClass: ObservableObject{
    let engine = AudioEngine()
    var instrument = AppleSampler()
    @Published var playing :[Bool] = Array(repeating: false, count: 4)
    let notes = [36,37,38,39]
    let names = ["KICK","CLOSED HI-HAT","SNARE","OPEN HI-HAT"]
    init() {
        engine.output = instrument
        loadInstrument()
        try? engine.start()
    }
    func loadInstrument() {
        do {
            if let fileURL =
                Bundle.main.url(forResource:
                                    "Sounds/drumSimp", withExtension:"exs") {
                try instrument.loadInstrument(url:fileURL)
            }else{
                Log("Could not find file")
            }
        } catch {
            Log("Could not load instrument")
        }
    }
}
struct DrumView: Identifiable ,View {
    @EnvironmentObject var conductor:  DrumClass
    var id: Int
    var body : some View {
        RoundedRectangle(cornerRadius: 20.0)
            .fill(Color.black.opacity(0.6))
            .aspectRatio(contentMode: .fit)
            .gesture(DragGesture(minimumDistance: 0, coordinateSpace: .local)
                .onChanged { _ in
                    if !conductor.playing[id] {
                        conductor.playing[id] = true
                        conductor.instrument.play(noteNumber: MIDINoteNumber(conductor.notes[id]), velocity: 90, channel: 0)
                    }
                }
                .onEnded { _ in
                    conductor.playing[id] = false
                })
            .overlay{
                Text (conductor.names[id]).foregroundColor(Color.white).allowsHitTesting(false)}
    }
}


struct ContentView: View {
    @StateObject var conductor = DrumClass()
    var body: some View {
        ZStack {
            RadialGradient(gradient: Gradient(colors: [.green.opacity(0.5), .black]), center: .center, startRadius: 2, endRadius: 650).edgesIgnoringSafeArea(.all)
            HStack{
                ForEach(0..<4)
                {x in
                    DrumView(id: x)
                    
                }.padding(10)
            }.environmentObject(conductor)
        }
    }
    
    
    struct ContentView_Previews: PreviewProvider {
        static var previews: some View {
            ContentView()
        }
    }
}
